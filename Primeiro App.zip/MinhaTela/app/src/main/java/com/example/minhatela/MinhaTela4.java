package com.example.minhatela;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MinhaTela4 extends AppCompatActivity {
    EditText txtDescricao;
    Button btnEnviar;
    SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minha_tela4);


        txtDescricao = (EditText) findViewById(R.id.txtDescricao);
        btnEnviar= (Button) findViewById(R.id.btnEnviar);

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrar();
            }
        });

    }

    public void cadastrar(){
        if( !TextUtils.isEmpty(txtDescricao.getText().toString())  ){
            try{
                bancoDados = openOrCreateDatabase("MinhaTela", MODE_PRIVATE, null);
                String sql = "INSERT INTO tweet (descricao) VALUES (?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindString(1,txtDescricao.getText().toString());
                stmt.executeInsert();
                bancoDados.close();
                finish();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}






