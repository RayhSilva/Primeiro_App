package com.example.minhatela;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtEmail1, txtSenha;
    Button btnEntrar;
    Button btnCriarConta;
    SQLiteDatabase bancoDados;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtEmail1 = (EditText) findViewById(R.id.txtEmail1);
        txtSenha = (EditText) findViewById(R.id.txtSenha);
        btnEntrar = (Button) findViewById(R.id.btnEntrar);
        btnCriarConta = (Button) findViewById(R.id.btnCriarConta);

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verificarLoginSenha();
                // vai chamar o metodo de fazer login
            }
        });
        btnCriarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               MinhaTela2();     }
        });

    }

    public void verificarLoginSenha() {
        String strLogin = txtEmail1.getText().toString();
        String strSenha = txtSenha.getText().toString();
        String str= "SELECT * FROM usuario WHERE Email='"+strLogin+ "' and Senha='"+strSenha+"'";
        bancoDados = openOrCreateDatabase("MinhaTela", MODE_PRIVATE, null);
        Cursor meuCursor= bancoDados.rawQuery(str,null);
        if (meuCursor.getCount()>0) {
            Toast.makeText(this, "Login com sucesso", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MinhaTela3.class);
            startActivity(intent);

        } else {
            Toast.makeText(this, "Falhou,Tente novamente!! ", Toast.LENGTH_SHORT).show();

        }


        }
    public void MinhaTela2 (){
        Intent intent = new Intent(this,MinhaTela2.class);
        startActivity(intent);}

    public void MinhaTela3 (){
        Intent intent = new Intent(this,MinhaTela3.class);
        startActivity(intent);
    }

}



