package com.example.minhatela;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MinhaTela2 extends AppCompatActivity {
    EditText txtNome, txtEmail2, txtSenha2;
    Button btnCadastrar;
    SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minha_tela2);

        txtEmail2 = (EditText) findViewById(R.id.txtEmail2);
        txtNome = (EditText) findViewById(R.id.txtEmail);
        txtSenha2 = (EditText) findViewById(R.id.txtSenha2);
        btnCadastrar = (Button) findViewById(R.id.btnCadastrar);

        criarBancoDados();

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                   Cadastrar();  }
        });

    }
    public void criarBancoDados(){

        try {
            bancoDados = openOrCreateDatabase("MinhaTela", MODE_PRIVATE, null);
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS usuario (" +
                    " Email VARCHAR PRIMARY KEY" +
                    " , Senha VARCHAR" +
                    " , Nome VARCHAR)");
            //bancoDados.execSQL("DELETE FROM animal");
            bancoDados.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Cadastrar() {
        if (!TextUtils.isEmpty(txtNome.getText().toString()) && !TextUtils.isEmpty(txtEmail2.getText().toString())& !TextUtils.isEmpty(txtSenha2.getText().toString())) {
            try {
                bancoDados = openOrCreateDatabase("MinhaTela", MODE_PRIVATE, null);
                String sql = "INSERT INTO usuario (Nome,Email,Senha) VALUES (?,?,?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindString(1, txtNome.getText().toString());
                stmt.bindString(2, txtEmail2.getText().toString());
                stmt.bindString(3, txtSenha2.getText().toString());
                stmt.executeInsert();
                bancoDados.close();
                finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

